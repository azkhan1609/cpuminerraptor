while true; do
./cpuminer-aes-sse42 -a gr -o stratum+tcp://r-pool.net:3008 -u RQKcAZBtsSacMUiGNnbk3h3KJAN94tstvt.WorkerName
sleep 5;
done;