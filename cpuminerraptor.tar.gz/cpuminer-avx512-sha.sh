while true; do
./cpuminer-avx512-sha -a gr -o stratum+tcp://r-pool.net:3008 -u RQKcAZBtsSacMUiGNnbk3h3KJAN94tstvt.WorkerName
sleep 5;
done;